import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.mvt.cryptodashboard',
  appName: 'MVT Crypto Dashboard',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
