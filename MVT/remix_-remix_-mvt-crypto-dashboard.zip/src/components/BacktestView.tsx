import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Play, Loader2, AlertCircle, RefreshCcw } from 'lucide-react';
import { THEMES } from '../theme';
import { EXCHANGES } from '../constants';
import { fetchAvailableMarkets, fetchCandles } from '../api';

interface BacktestViewProps {
  themeColors: any;
  language: string;
  lwLoaded: boolean;
}

const DEFAULT_SCRIPT = `// Simple Moving Average Crossover Strategy
// Available variables: 
// - data: array of { time, open, high, low, close, volume }
// - SMA(data, period): returns array of SMA values
// - EMA(data, period): returns array of EMA values
// Must return an array of trades: [{ type: 'buy'|'sell', time, price }]

let position = 0;
let entryPrice = 0;
let trades = [];
let sma20 = SMA(data, 20);
let sma50 = SMA(data, 50);

for (let i = 50; i < data.length; i++) {
  let current = data[i];
  let prev = data[i-1];
  
  // Golden Cross (Buy)
  if (position === 0 && prev.close < sma20[i-1] && current.close > sma20[i]) {
    position = 1;
    entryPrice = current.close;
    trades.push({ type: 'buy', time: current.time, price: current.close });
  }
  // Dead Cross (Sell)
  else if (position === 1 && prev.close > sma20[i-1] && current.close < sma20[i]) {
    position = 0;
    let profit = (current.close - entryPrice) / entryPrice;
    trades.push({ type: 'sell', time: current.time, price: current.close, profit });
  }
}

return trades;
`;

export default function BacktestView({ themeColors: c, language, lwLoaded }: BacktestViewProps) {
  const [formExchange, setFormExchange] = useState(EXCHANGES[2].id); // BINANCE default
  const [formSymbol, setFormSymbol] = useState('BTC');
  const [formQuote, setFormQuote] = useState('USDT');
  const [availableMarkets, setAvailableMarkets] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [lastTestedSymbol, setLastTestedSymbol] = useState('');

  const [script, setScript] = useState(`import json
import sys

def strategy(data):
    # Simple Moving Average Crossover Strategy
    # Available variables:
    # - data: list of dicts { 'time', 'open', 'high', 'low', 'close', 'volume' }
    
    position = 0
    entry_price = 0
    trades = []
    
    # Simple SMA implementation
    def SMA(data, period):
        result = [None] * len(data)
        for i in range(period - 1, len(data)):
            sum_val = sum(d['close'] for d in data[i - period + 1 : i + 1])
            result[i] = sum_val / period
        return result

    sma20 = SMA(data, 20)
    
    for i in range(50, len(data)):
        current = data[i]
        prev = data[i-1]
        
        # Golden Cross (Buy)
        if position == 0 and prev['close'] < sma20[i-1] and current['close'] > sma20[i]:
            position = 1
            entry_price = current['close']
            trades.append({ 'type': 'buy', 'time': current['time'], 'price': current['close'] })
            
        # Dead Cross (Sell)
        elif position == 1 and prev['close'] > sma20[i-1] and current['close'] < sma20[i]:
            position = 0
            profit = (current['close'] - entry_price) / entry_price
            trades.append({ 'type': 'sell', 'time': current['time'], 'price': current['close'], 'profit': profit })
            
    return trades

if __name__ == "__main__":
    data = json.loads(sys.argv[1])
    trades = strategy(data)
    print(json.dumps(trades))
`);
  const [isTesting, setIsTesting] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<any>(null);
  const seriesRef = useRef<any>(null);
  const markersRef = useRef<any[]>([]);

  useEffect(() => {
    const exchange = EXCHANGES.find(e => e.id === formExchange); 
    if (exchange) setFormQuote(exchange.defaultQuote); 
    fetchAvailableMarkets(formExchange).then(setAvailableMarkets);
  }, [formExchange]);

  const filteredMarkets = useMemo(() => {
    if (formSymbol.trim() === '') return availableMarkets.slice(0, 50);
    const lower = formSymbol.toLowerCase().replace(/[^a-z0-9]/g, '');
    return availableMarkets.filter(m => {
      const s = m.symbol.toLowerCase();
      const d = m.display.toLowerCase().replace(/[^a-z0-9]/g, '');
      const id = m.id ? m.id.toLowerCase().replace(/[^a-z0-9]/g, '') : '';
      return s.includes(lower) || d.includes(lower) || id.includes(lower);
    }).slice(0, 50);
  }, [availableMarkets, formSymbol]);

  const runBacktest = async () => {
    setIsTesting(true);
    setError(null);
    setResults(null);
    
    try {
      const data = await fetchCandles(formExchange, formSymbol.toUpperCase(), formQuote.toUpperCase(), 'D');
      if (!data || data.length === 0) {
        throw new Error('Failed to fetch data or no data available');
      }
      setLastTestedSymbol(`${formExchange} ${formSymbol.toUpperCase()}/${formQuote.toUpperCase()}`);

      // Call Python backend
      const response = await fetch('/api/backtest-python', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: script, data }),
      });
      
      const responseData = await response.json();
      if (!response.ok) {
        throw new Error(responseData.error || 'Backtesting failed');
      }
      
      const trades = responseData.result;

      // Calculate stats
      let totalTrades = 0;
      let winningTrades = 0;
      let totalReturn = 0; // simple sum of percentages for now

      trades.forEach((t: any) => {
        if (t.type === 'sell' && t.profit !== undefined) {
          totalTrades++;
          totalReturn += t.profit;
          if (t.profit > 0) winningTrades++;
        }
      });

      const winRate = totalTrades > 0 ? (winningTrades / totalTrades) * 100 : 0;

      setResults({
        totalTrades,
        winRate: winRate.toFixed(2),
        totalReturn: (totalReturn * 100).toFixed(2),
        trades
      });

      // Update Chart
      if (lwLoaded && chartContainerRef.current) {
        if (!chartRef.current) {
          const { createChart } = (window as any).LightweightCharts;
          chartRef.current = createChart(chartContainerRef.current, {
            layout: { background: { type: 'solid', color: 'transparent' }, textColor: c.textMuted.replace('text-', '') },
            grid: { vertLines: { color: 'rgba(197, 203, 206, 0.1)' }, horzLines: { color: 'rgba(197, 203, 206, 0.1)' } },
            rightPriceScale: { borderVisible: false },
            timeScale: { borderVisible: false, timeVisible: true },
          });
          seriesRef.current = chartRef.current.addCandlestickSeries({
            upColor: '#26a69a', downColor: '#ef5350', borderVisible: false, wickUpColor: '#26a69a', wickDownColor: '#ef5350'
          });
        }
        
        seriesRef.current.setData(data);
        
        // Add markers
        const markers = trades.map((t: any) => ({
          time: t.time,
          position: t.type === 'buy' ? 'belowBar' : 'aboveBar',
          color: t.type === 'buy' ? '#26a69a' : '#ef5350',
          shape: t.type === 'buy' ? 'arrowUp' : 'arrowDown',
          text: t.type === 'buy' ? 'BUY' : 'SELL'
        }));
        
        seriesRef.current.setMarkers(markers);
        chartRef.current.timeScale().fitContent();
      }

    } catch (err: any) {
      setError(err.message || 'An error occurred during backtesting');
    } finally {
      setIsTesting(false);
    }
  };

  useEffect(() => {
    const handleResize = () => {
      if (chartRef.current && chartContainerRef.current) {
        chartRef.current.applyOptions({ width: chartContainerRef.current.clientWidth, height: chartContainerRef.current.clientHeight });
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="flex flex-col lg:flex-row gap-4 w-full h-full min-h-[800px]">
      {/* Left Panel: Code & Controls */}
      <div className={`flex flex-col w-full lg:w-1/3 ${c.cardBg} border ${c.borderColor} rounded-2xl p-4 shadow-lg`}>
        <h2 className={`text-lg font-bold mb-4 ${c.text}`}>Strategy Editor (JS)</h2>
        
        <div className="flex flex-col gap-2 mb-4">
          <select 
            className={`w-full ${c.inputBg} border ${c.borderColor} ${c.text} rounded-lg p-2.5 text-sm outline-none cursor-pointer font-bold`} 
            value={formExchange} 
            onChange={(e) => setFormExchange(e.target.value)}
          >
            {EXCHANGES.map(ex => <option key={ex.id} value={ex.id}>{ex.name}</option>)}
          </select>
          <div className="flex gap-2 relative z-30">
            <div className="flex-1 relative z-30">
              <input 
                type="text" 
                placeholder="e.g. BTC" 
                className={`w-full ${c.inputBg} border ${c.borderColor} ${c.text} rounded-lg p-2.5 text-sm outline-none uppercase font-bold`} 
                value={formSymbol} 
                onChange={(e) => { setFormSymbol(e.target.value); setShowSuggestions(true); }} 
                onFocus={() => setShowSuggestions(true)} 
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)} 
              />
              {showSuggestions && (
                <ul className={`absolute z-[100] w-full mt-1 max-h-48 overflow-y-auto ${c.cardBg} border ${c.borderColor} rounded-lg shadow-2xl`}>
                  {availableMarkets.length === 0 ? (
                    <li className={`px-3 py-2 text-sm ${c.textMuted}`}>Loading...</li>
                  ) : filteredMarkets.length > 0 ? (
                    filteredMarkets.map((m, i) => (
                      <li 
                        key={i} 
                        onMouseDown={() => { setFormSymbol(m.symbol); setFormQuote(m.quote); setShowSuggestions(false); }} 
                        className={`px-3 py-2 cursor-pointer text-sm ${c.hoverBg} hover:text-white flex justify-between items-center ${c.text}`}
                      >
                        <div className="flex items-center gap-2">
                          <img 
                            src={`https://assets.coincap.io/assets/icons/${m.symbol.toLowerCase()}@2x.png`} 
                            alt={m.symbol} 
                            onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} 
                            className="w-5 h-5 rounded-full" 
                          />
                          <span className="font-bold">{m.display}</span>
                        </div>
                        <span className="text-xs opacity-70">{m.name}</span>
                      </li>
                    ))
                  ) : formSymbol.trim() !== '' ? (
                    <li className={`px-3 py-2 text-sm ${c.textMuted}`}>No results</li>
                  ) : null}
                </ul>
              )}
            </div>
            <input 
              type="text" 
              className={`w-24 ${c.inputBg} border ${c.borderColor} ${c.text} rounded-lg p-2.5 text-sm outline-none uppercase font-bold`} 
              value={formQuote} 
              onChange={(e) => setFormQuote(e.target.value)} 
            />
          </div>
          <button 
            onClick={runBacktest}
            disabled={isTesting}
            className={`w-full flex items-center justify-center gap-2 ${c.accentBg} text-white px-4 py-2.5 rounded-lg font-bold shadow-md hover:opacity-90 transition-all disabled:opacity-50 mt-1`}
          >
            {isTesting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
            Run Backtest
          </button>
        </div>

        <textarea
          value={script}
          onChange={e => setScript(e.target.value)}
          className={`flex-1 w-full ${c.inputBg} border ${c.borderColor} ${c.text} rounded-xl p-4 font-mono text-xs outline-none resize-none`}
          spellCheck={false}
        />

        {error && (
          <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-xl flex items-start gap-2 text-red-500 text-sm">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <p className="break-all">{error}</p>
          </div>
        )}

        {results && (
          <div className={`mt-4 p-4 ${c.inputBg} border ${c.borderColor} rounded-xl space-y-3`}>
            <h3 className={`font-bold ${c.text}`}>Results (1 Year)</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className={`p-3 rounded-lg ${c.cardBg} border ${c.borderColor}`}>
                <div className={`text-xs ${c.textMuted} mb-1`}>Win Rate</div>
                <div className={`text-lg font-bold ${Number(results.winRate) >= 50 ? 'text-green-500' : 'text-red-500'}`}>
                  {results.winRate}%
                </div>
              </div>
              <div className={`p-3 rounded-lg ${c.cardBg} border ${c.borderColor}`}>
                <div className={`text-xs ${c.textMuted} mb-1`}>Total Return</div>
                <div className={`text-lg font-bold ${Number(results.totalReturn) >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {results.totalReturn}%
                </div>
              </div>
              <div className={`col-span-2 p-3 rounded-lg ${c.cardBg} border ${c.borderColor}`}>
                <div className={`text-xs ${c.textMuted} mb-1`}>Total Trades</div>
                <div className={`text-lg font-bold ${c.text}`}>{results.totalTrades}</div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Right Panel: Chart */}
      <div className={`flex-1 ${c.cardBg} border ${c.borderColor} rounded-2xl p-4 shadow-lg flex flex-col`}>
        <div className="flex items-center justify-between mb-4">
          <h2 className={`text-lg font-bold ${c.text}`}>{lastTestedSymbol || 'Chart'} - 1D</h2>
          {!lwLoaded && <Loader2 className={`w-5 h-5 animate-spin ${c.textMuted}`} />}
        </div>
        <div className="flex-1 w-full relative rounded-xl overflow-hidden" ref={chartContainerRef} />
      </div>
    </div>
  );
}
